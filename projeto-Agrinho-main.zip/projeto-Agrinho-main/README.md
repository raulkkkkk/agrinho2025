<h1 aling:center>Projeto Agrinho</h1>
 Este site é um projeto feito pelo aluno Gabriel Augusto Honesko, da segunda série A do Colégio Estadual Alberto de Carvalho para a participação no Programa Agrinho de programação 2024.
 O projeto conta com elementos gráficos retirados do Canva e fotos (créditos das fotos no último parágrafo), todos os conhecimentos adquiridos para a contrução do site vieram do curso do alura disponibilizado pelo Governo do Estado do Paraná.
 O site conta com estilizações e div's, clicando no botão você será direcionado para a cordenada onde ocorre a Feira do Agricultor descrita no site.
 Há também botões clicaveis no rodapé do site além de diversas "sections", cabeçalho, rodapé e outros elementos.
 O site foi desenvolvido no Visual Studio Code com lingaugens de HTML e CSS, os elementos foram organizados e posicionados conforme a tela de um nootebook.
 Direitos autorais das fotos contidas no projeto= foto da feira do agricultor e da pesanka: reprodução pref. de Prudentópolis, foto da krakovia: Carolina Mainardes (globo rural), foto das frutas e vegetais: Lazada Philippines.

 # Autor:

Gabriel Augusto Honesko
